

<?php $__env->startSection('title', 'Urutan'); ?>

<?php $__env->startSection('content'); ?>
    Urutan ke - <?php echo e($numbers['ke']); ?>

    Nomor ke - <?php echo e($numbers[$nomor); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\htdocs\laravelpertama\resources\views/urutan.blade.php ENDPATH**/ ?>