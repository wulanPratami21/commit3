@extends('layouts.app')

@section('title', 'cobaaaaaa')

@section('content')
    Urutan ke - {{ $ke }}
@endsection
